# Changelog

## 0.1.0 — 2026-07-07

### Added

- Initial release: Retry with exponential backoff, circuit breaker, and rate limiting.
